{-# LANGUAGE EmptyDataDecls, ExistentialQuantification,
  ScopedTypeVariables, NoMonomorphismRestriction, Rank2Types #-}
module MAlonzo.Code.Algebra.FunctionProperties.Core where
import MAlonzo.RTE (coe, erased)
import qualified Control.Exception
import qualified Data.Text
import qualified Data.Text.IO
import qualified MAlonzo.RTE
import qualified System.IO
import qualified Data.Text
import qualified MAlonzo.Code.Level
name8 = "Algebra.FunctionProperties.Core.Op\8321"
d8 = erased
name14 = "Algebra.FunctionProperties.Core.Op\8322"
d14 = erased