{-# LANGUAGE EmptyDataDecls, ExistentialQuantification,
  ScopedTypeVariables, NoMonomorphismRestriction, Rank2Types #-}
module MAlonzo.Code.Agda.Builtin.Unit where
import MAlonzo.RTE (coe, erased)
import qualified MAlonzo.RTE
import qualified Data.Text
name6 = "Agda.Builtin.Unit.\8868"
d6 = ()

data T6 = C8
name8 = "Agda.Builtin.Unit.\8868.tt"

d8 :: ()
d8 = ()